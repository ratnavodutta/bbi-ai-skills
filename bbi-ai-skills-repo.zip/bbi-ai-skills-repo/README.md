# bbi-ai-skills

Internal Blackbaud repository for custom Claude Skills.

## Layout

Skills live under `Claude/<skill-name>/`, matching the folder structure Claude's skill uploader expects:

```
Claude/<skill-name>/
  SKILL.md              # required — YAML frontmatter (name, description) + instructions
  references/            # optional — reference docs the skill reads on demand
  scripts/                # optional — code the skill can execute
```

To upload a skill via the Claude portal/Cowork, zip the **contents** of a `Claude/<skill-name>/` folder (so `SKILL.md` sits at the zip root, not nested under another folder) and upload the zip.

## Skills in this repo

### `Claude/net`

Senior network incident engineer / cloud network architect skill. Four independently invocable phases:

- **Phase 0** — AWS/Azure architecture design (Well-Architected, landing zones, HLD/LLD, migration, VPC/VNet design).
- **Phase 1** — Ingest, scope and triage an active or reported network issue into a hypothesis-driven roadmap.
- **Phase 2** — Active diagnosis via Azure CLI, AWS CLI, Cisco IOS/IOS-XE, Cisco ASA/FTD, Palo Alto, Citrix NetScaler/ADC, Cisco Meraki, and host-level Windows/Linux checks (including no-admin techniques and bandwidth tests).
- **Phase 3** — Technical/executive summaries and a canonical Excel incident workbook, kept updated in place rather than duplicated.

Bundles a Python client-network-agent runtime (`scripts/client_network_agent/`) for one-shot end-host evidence collection (DNS, TCP, HTTP, OS-native commands) — see `Claude/net/references/client-network-agent.md` for usage.

Merged from two source projects during the 2026-08-25 Cowork session: the original `net` skill (troubleshooting playbooks + architecture references) and a standalone `client_network_agent` runtime, so Claude can invoke the bundled runtime directly instead of only describing individual commands.

## Adding a new skill

1. Create `Claude/<new-skill-name>/SKILL.md` with YAML frontmatter (`name`, `description` — max 1024 characters).
2. Add any `references/` or `scripts/` the skill needs.
3. Update this README's skill list.
4. Commit and push.
